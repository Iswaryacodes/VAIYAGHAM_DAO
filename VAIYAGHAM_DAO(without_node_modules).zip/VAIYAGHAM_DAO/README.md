# Sample DAO Project

This project demonstrates DAO concept. It is the project where we can donate certain amount to be a stakeholder. The stakeholder can propose a proposal and the execution of the proposal is fully depends on the votes of all the stakeholders before the time lapse.

Try running some of the following tasks:

```shell

npx hardhat test
npx hardhat node
npx hardhat run scripts/deploy.js  //including localhost network flag
paste the  deployed address in blockchain.jsx
npm start

install metamask and add pinned extension for easy use
In metamask,
login add localhost acccounts to it //new RPC http://127.0.0.1:8545/
connect metamask to localhost network

```

_) Donate minimum of 1ETH and become a stakeholder.
_) contribute min of 1ETH and propose a proposal.
_) get votes from other stakeholders before the time period completion.
_) the votes can be revealed on a page with pictorial representation of bar chart.
_) once the timeperiod is completed, the proposal will be executed accordingly.
_) if success, the beneficiary will get reward.
