import Identicon from 'react-identicons'
import moment from 'moment'
import { useState, useEffect } from 'react'
import { useParams } from 'react-router-dom'
import { truncate } from '../store'
import { listVoters } from '../Blockchain'

const Voters = () => {
  const [voters, setVoters] = useState([])
  const [data, setData] = useState([])
  const { id } = useParams()
  
  const deactive = `bg-transparent
  text-blue-600 font-medium text-xs leading-tight
  uppercase hover:bg-blue-700 focus:bg-blue-700
  focus:outline-none focus:ring-0 active:bg-blue-600
  transition duration-150 ease-in-out overflow-hidden
  border border-blue-600 hover:text-white focus:text-white`

  const active = `bg-blue-600
  text-white font-medium text-xs leading-tight
  uppercase hover:bg-blue-700 focus:bg-blue-700
  focus:outline-none focus:ring-0 active:bg-blue-800
  transition duration-150 ease-in-out overflow-hidden
  border border-blue-600`

  useEffect(async () => {
    await listVoters(id).then((res) => {
      setVoters(res)
      setData(res)
    })
  }, [id])

  const getAll = () => setVoters(data)
  const getAccepted = () => setVoters(data.filter((vote) => vote.chosen))
  const getRejected = () => setVoters(data.filter((vote) => !vote.chosen))

  return (
    <div className="flex flex-col p-8">
      <div className="flex flex-row justify-center items-center" role="group">
        <button onClick={getAll} className={`rounded-l-full px-6 py-2.5 ${deactive}`} > All </button>
        <button onClick={getAccepted} className={`px-6 py-2.5 ${deactive}`}> Acceptees </button>
        <button onClick={getRejected} className={`rounded-r-full px-6 py-2.5 ${deactive}`}> Rejectees </button>
      </div>
      
      <div className="overflow-x-auto sm:-mx-6 lg:-mx-8">
        <div className="py-2 inline-block min-w-full sm:px-6 lg:px-8">
          <div className="h-[calc(100vh_-_20rem)] overflow-y-auto  shadow-md rounded-md">
            <table className="min-w-full">
              <thead className="border-b dark:border-gray-500">
                <tr>
                  <th
                    scope="col"
                    className="text-sm font-medium px-6 py-4 text-left">
                    Voter
                  </th>
                  <th
                    scope="col"
                    className="text-sm font-medium px-6 py-4 text-left">
                    Voted
                  </th>
                  <th
                    scope="col"
                    className="text-sm font-medium px-6 py-4 text-left">
                    Vote
                  </th>
                </tr>
              </thead>
              <tbody>             
                    {voters.map((voter, i) => (
                      <Voter key={i} vote={voter} />
                    ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
     </div>
  )
}

const Voter = ({vote}) =>{
  const timeAgo = (timestamp) => moment(Number(timestamp + '000')).fromNow()
  return (
  <tr>
    <td className="text-sm font-light px-6 py-4 whitespace-nowrap">
      <div className="flex flex-row justify-start items-center space-x-3">
      <Identicon
      string={vote.voter.toLowerCase()}
      size={25}
      className="h-10 w-10 object-contain rounded-full mr-3"
      />
      <span>{truncate(vote.voter, 4, 4, 11)}</span>
      </div>
    </td>                  

    <td className="text-sm font-light px-6 py-4 whitespace-nowrap">
      {timeAgo(vote.timestamp)}
    </td>

    <td className="text-sm font-light px-6 py-4 whitespace-nowrap space-x-2">
      {vote.chosen? (
        <button
        className="bg-blue-600 text-white font-medium text-sm leading-tight uppercase rounded-full 
        shadow-md shadow-gray-400 px-4 py-2.5
        active:bg-blue-800 
        dark:shadow-transparent dark:border-blue-500  
        transition duration-150 ease-in-out 
        border border-blue-600 
        hover:text-white hover:bg-blue-700"
        >
      Accepted
      </button>
      ):(
        <button
      className="bg-red-600 text-white font-medium text-sm leading-tight uppercase rounded-full 
        shadow-md shadow-gray-400 px-4 py-2.5
        active:bg-red-800 
        dark:shadow-transparent dark:border-red-500  
        transition duration-150 ease-in-out 
        border border-red-600 
        hover:text-white hover:bg-red-700"
      >
      Rejected
      </button>
      ) }                  
      
                      
      
                      
    </td>
  </tr>
)}

export default Voters
